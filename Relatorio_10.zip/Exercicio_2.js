class Pistola {
    constructor(modelo) {
        this.modelo = modelo;
    }
}

class AgenteProtocolo {
    #pistola;

    constructor(codinome, modeloDaPistola) {
        this.codinome = codinome;
        
        this.#pistola = new Pistola(modeloDaPistola);
    }

    usarHabilidade() {
        throw new Error("Erro: O método usarHabilidade() deve ser implementado nas classes filhas.");
    }

    entrarEmCombate() {
        console.log(`[${this.codinome}] entrou em combate com uma pistola ${this.#pistola.modelo} e usou: ${this.usarHabilidade()}`);
    }
}

class Controlador extends AgenteProtocolo {
    usarHabilidade() {
        return "Fumaça espessa para bloquear a visão dos inimigos!";
    }
}

class Iniciador extends AgenteProtocolo {
    usarHabilidade() {
        return "Flecha rastreadora para revelar posições!";
    }
}

class Duelista extends AgenteProtocolo {
    usarHabilidade() {
        return "Avanço rápido para iniciar o confronto direto!";
    }
}

class Esquadrao {
    #agentes;

    constructor(nome, agentes) {
        this.nome = nome;
        this.#agentes = agentes; 
    }

    iniciarPartida() {
        console.log(`\n=== Iniciando partida com o esquadrão: ${this.nome} ===`);
        this.#agentes.forEach(agente => agente.entrarEmCombate());
    }

    listarControladores() {
        return this.#agentes.filter(agente => agente instanceof Controlador);
    }
}

const omen = new Controlador("Omen", "Ghost");
const brimstone = new Controlador("Brimstone", "Classic");
const sova = new Iniciador("Sova", "Sheriff");
const jett = new Duelista("Jett", "Frenzy");

const agentesVanguard = [omen, brimstone, sova, jett];
const esquadraoVanguard = new Esquadrao("Vanguard", agentesVanguard);

esquadraoVanguard.iniciarPartida();

console.log("\n=== Lista de Controladores no Esquadrão ===");
const controladores = esquadraoVanguard.listarControladores();
controladores.forEach(agente => console.log(agente.codinome));

const agenteGenerico = new AgenteProtocolo("Recruta", "Classic");

// A linha abaixo gera o erro " throw new Error("Erro: O método usarHabilidade() deve ser implementado nas classes filhas.");"
//agenteGenerico.entrarEmCombate();