class Pokemon {
    #vida; 

    constructor(apelido, tipo, vidaInicial) {
        this.apelido = apelido;
        this.tipo = tipo;
        
        this.#vida = vidaInicial;
    }

    get vida() {
        return this.#vida;
    }

    sofrerDano(pontos) {
        this.#vida -= pontos;
        
        if (this.#vida < 0) {
            this.#vida = 0;
        }
        
        console.log(`${this.apelido} sofreu dano! Vida restante: ${this.#vida}`);
    }

    atacar(alvo) {
        console.log(`${this.apelido} usou um ataque genérico!`);
        alvo.sofrerDano(10);
    }
}

class Squirtle extends Pokemon {
    constructor(apelido, vidaInicial) {
        super(apelido, 'Água', vidaInicial);
    }

    atacar(alvo) {
        console.log(`${this.apelido} usou Jato de Água!`);
        alvo.sofrerDano(20); 
    }
}

class Bulbasaur extends Pokemon {
    constructor(apelido, vidaInicial) {
        super(apelido, 'Planta', vidaInicial);
    }

    atacar(alvo) {
        console.log(`${this.apelido} usou Chicote Cepa!`);
    }
}

console.log("--- Batalha de Ginásio ---");

const meuSquirtle = new Squirtle("Kame", 40);
const meuBulbasaur = new Bulbasaur("Saur", 30);

meuBulbasaur.atacar(meuSquirtle);

meuSquirtle.atacar(meuBulbasaur);
meuSquirtle.atacar(meuBulbasaur);

console.log("\n--- Resultado Final ---");
console.log(`Vida do ${meuSquirtle.apelido}: ${meuSquirtle.vida}`);
console.log(`Vida do ${meuBulbasaur.apelido}: ${meuBulbasaur.vida}`);

// 5. Tentativa de imprimir #vida diretamente
// O código abaixo gera o erro "SyntaxError: Private field '#vida' must be declared in an enclosing class"
//console.log(meuSquirtle.#vida);