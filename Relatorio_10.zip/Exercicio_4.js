class UsuarioDeNen {
    constructor(nome) {
        this.nome = nome;
    }

    atacar(alvo) {
        console.log(`${this.nome} lança um ataque genérico de aura contra a Aranha ${alvo.nome}!`);
    }
}

class Intensificador extends UsuarioDeNen {
    atacar(alvo) {
        console.log(`${this.nome} concentra 100% de sua aura no punho e dá um soco devastador na Aranha ${alvo.nome}!`);
    }
}

class Transmutador extends UsuarioDeNen {
    atacar(alvo) {
        console.log(`${this.nome} transmuta sua aura em eletricidade de alta voltagem e atinge a Aranha ${alvo.nome}!`);
    }
}

class Materializador extends UsuarioDeNen {
    atacar(alvo) {
        console.log(`${this.nome} materializa correntes indestrutíveis para prender a Aranha ${alvo.nome}!`);
    }
}

class Aranha {
    constructor(nome, numero) {
        this.nome = nome;
        this.numero = numero;
    }
}

class TrupeFantasma {
    #aranhas;

    constructor(cidade, aranhas = []) {
        this.cidade = cidade;
        this.#aranhas = aranhas;
    }

    revelarAranhas() {
        console.log(`\n--- Trupe Fantasma avistada em: ${this.cidade} ---`);
        this.#aranhas.forEach(aranha => {
            console.log(`Aranha #${aranha.numero}: ${aranha.nome}`);
        });
    }

    buscarAranha(numero) {
        return this.#aranhas.find(aranha => aranha.numero === numero);
    }
}

const chrollo = new Aranha("Chrollo Lucilfer", 0);
const hisoka = new Aranha("Hisoka Morow", 4);

const trupe = new TrupeFantasma("Yorknew City", [chrollo, hisoka]);

trupe.revelarAranhas();

const aranhaAlvo = trupe.buscarAranha(4);

console.log("\n--- Início do Combate ---");

const gon = new Intensificador("Gon Freecss");
const killua = new Transmutador("Killua Zoldyck");
const kurapika = new Materializador("Kurapika");

const equipeHunters = [gon, killua, kurapika];

equipeHunters.forEach(hunter => {
    hunter.atacar(aranhaAlvo);
});