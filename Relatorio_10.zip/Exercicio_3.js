class FichaDeCriatura {
    constructor(criatura, nivelDePerigo) {
        this.criatura = criatura;
        this.nivelDePerigo = nivelDePerigo;
    }

    descrever() {
        return `Criatura: ${this.criatura} | Nível de Perigo: ${this.nivelDePerigo}`;
    }
}

class DiarioMisterioso {
    #fichas;

    constructor(numero) {
        this.numero = numero;
        this.#fichas = [];
    }

    anotar(criatura, nivelDePerigo) {
        const novaFicha = new FichaDeCriatura(criatura, nivelDePerigo);
        this.#fichas.push(novaFicha);
    }

    exibirFichas() {
        console.log(`\n--- Lendo o Diário nº ${this.numero} ---`);
        this.#fichas.forEach(ficha => {
            console.log(ficha.descrever()); 
        });
    }
}

class Funcionario {
    constructor(nome, cargo) {
        this.nome = nome;
        this.cargo = cargo;
    }
}

class CabanaDoMisterio {
    #funcionarios;

    constructor(dono) {
        this.dono = dono;
        this.#funcionarios = [];
    }

    contratar(funcionario) {
        this.#funcionarios.push(funcionario);
    }

    abrirAsPortas() {
        console.log(`\n--- A Cabana do Mistério (Dono: ${this.dono}) está ABERTA! ---`);
        console.log("Equipa de Serviço:");
        this.#funcionarios.forEach(func => {
            console.log(`- ${func.nome} (${func.cargo})`);
        });
    }
}

const diario3 = new DiarioMisterioso(3);
diario3.anotar("Gnomos", "Baixo (mas podem formar um gigante)");
diario3.anotar("Multiuso (Gobblewonker)", "Médio (se for real)");
diario3.anotar("Bill Cipher", "Extremamente Alto");

diario3.exibirFichas();

const soos = new Funcionario("Soos Ramirez", "Faz-tudo");
const wendy = new Funcionario("Wendy Corduroy", "Atendente de Caixa");

const cabanaDoTioStan = new CabanaDoMisterio("Stan Pines");
cabanaDoTioStan.contratar(soos);
cabanaDoTioStan.contratar(wendy);

cabanaDoTioStan.abrirAsPortas();

/*
  6.
  - COMPOSIÇÃO (Dependência Total): 
    As Fichas nascem e morrem com o Diário. Elas são criadas diretamente lá dentro[cite: 12].

  - AGREGAÇÃO (Independência): 
    Os Funcionários têm vida própria. Eles são criados fora da Cabana e continuam a existir mesmo se ela fechar[cite: 13].
*/