use std::io;

fn validar_placa(placa: &str) -> bool {
    if placa.len() >= 7{
        let mut mai = 0;
        let mut min = 0;
        for c in placa.chars() {
            if c.is_ascii_uppercase() {
                mai +=1;
            }
            if c.is_numeric() {
                min +=1;
            }
        }
        if mai >= 4{
            if min >= 2{
                true
            }else{
                false
            }
        }else{
            false
        }
    }else{
        false 
    }
}

fn main(){
    loop{
        let mut entrada = String::new();
        println!("Digite a placa:");


        io::stdin().read_line(&mut entrada).expect("Erro ao ler");

        let placa = entrada.trim();
        
        if validar_placa(placa){
            println!("Placa cadastrada no sistema");
            break;
        }else{
            println!("Placa invalida. Tente novamente")
        }
        }
}