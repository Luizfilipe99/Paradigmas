use std::io;

fn calcular_pontuacao(prova1: f64, prova2: f64, redacao: f64) -> f64 {
    let npt = (prova1 + prova2) / 2.0;
    

    let pf = (npt * 0.6) + (redacao * 0.4);

    if pf >= 60.0 {
        println!("Parabens! Candidato aprovado no processo seletivo. Resultado: {:.2}", pf);
    } else {
        println!("Infelizmente o candidato nao atingiu a pontuacao minima de aprovacao. Resultado: {:.2}", pf);
    }

    pf
}

fn main() {
    let mut entrada1 = String::new();
    let mut entrada2 = String::new();
    let mut entrada3 = String::new();

    println!("Digite a nota da Prova 1:");
    io::stdin().read_line(&mut entrada1).expect("Erro ao ler a Prova 1");
    let prova1: f64 = entrada1.trim().parse().unwrap_or(0.0);

    println!("Digite a nota da Prova 2:");
    io::stdin().read_line(&mut entrada2).expect("Erro ao ler a Prova 2");
    let prova2: f64 = entrada2.trim().parse().unwrap_or(0.0);

    println!("Digite a nota da Redacao:");
    io::stdin().read_line(&mut entrada3).expect("Erro ao ler a Redacao");
    let redacao: f64 = entrada3.trim().parse().unwrap_or(0.0);

    let resultado_final = calcular_pontuacao(prova1, prova2, redacao);
    
    println!("\nValor retornado pela funcao: {:.2}", resultado_final);
}