using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Pokemon
{
    public string Especie { get; set; }
    public int Nivel { get; set; }

    public Pokemon(string especie, int nivel)
    {
        Especie = especie;
        Nivel = nivel;
    }

    public virtual void Atacar()
    {
        Console.WriteLine($"{Especie} (Nível {Nivel}) usou um Ataque Comum!");
    }
}

public class TipoPlanta : Pokemon
{
    public TipoPlanta(string especie, int nivel) : base(especie, nivel)
    {
    }

    public override void Atacar()
    {
        Console.WriteLine($"{Especie} (Nível {Nivel}) usou Chicote de Vinha!");
    }
}

public class TipoEletrico : Pokemon
{
    public TipoEletrico(string especie, int nivel) : base(especie, nivel)
    {
    }

    public override void Atacar()
    {
        base.Atacar();
        Console.WriteLine($"{Especie} soltou uma descarga elétrica de Choque do Trovão!");
    }
}

class Program
{
    static void Main(string[] args)
    {
        List<Pokemon> pokedex = new List<Pokemon>
        {
            new Pokemon("Eevee", 10),
            new TipoPlanta("Bulbasaur", 15),
            new TipoEletrico("Pikachu", 20)
        };

        Console.WriteLine("--- Batalha de Exibição Pokémon ---");
        
        foreach (Pokemon p in pokedex)
        {
            p.Atacar();
            Console.WriteLine(); 
        }
    }
}