using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class CombatenteDeGondor
{
    public string Nome { get; private set; }
    public string Povo { get; private set; }
    public string Posto { get; private set; }

    public string Armamento { get; private set; } = "Desarmado";

    public CombatenteDeGondor(string nome, string povo, string posto)
    {
        Nome = nome;
        Povo = povo;
        Posto = posto;
    }

    public void Equipar(string arma)
    {
        Armamento = arma;
    }

    public void ApresentarUnidade()
    {
        Console.WriteLine($"Nome: {Nome} | Povo: {Povo} | Posto: {Posto}");
        
        if (Armamento != "Desarmado")
        {
            Console.WriteLine($"Armamento: {Armamento}");
        }
        Console.WriteLine(new string('-', 40));
    }
}

class Program
{
    static void Main(string[] args)
    {
        CombatenteDeGondor combatente1 = new CombatenteDeGondor("Aragorn", "Dúnedain", "Capitão");
        CombatenteDeGondor combatente2 = new CombatenteDeGondor("Beregond", "Gondoriano", "Guarda da Cidadela");
        CombatenteDeGondor combatente3 = new CombatenteDeGondor("Pippin", "Hobbit", "Soldado");

        combatente1.Equipar("Andúril");
        combatente2.Equipar("Lança e Espada");

        combatente1.ApresentarUnidade();
        combatente2.ApresentarUnidade();
        combatente3.ApresentarUnidade();

        // combatente1.Posto = "Rei"; 
		// Exercicio_1.cs(53,21): error CS0272: The property or indexer `CombatenteDeGondor.Posto' cannot be used in this context because the set accessor is inaccessible
	}
}