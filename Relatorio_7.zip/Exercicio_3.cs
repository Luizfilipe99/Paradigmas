using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Grimorio
{
    public string FeiticoFavorito { get; set; } = "Nenhum";

    public void Abrir()
    {
        Console.WriteLine($"Grimório aberto. Feitiço favorito: {FeiticoFavorito}");
    }
}

public class Companheiro
{
    public string Nome { get; set; }
    public string Funcao { get; set; }

    public Companheiro(string nome, string funcao)
    {
        Nome = nome;
        Funcao = funcao;
    }

    public void Apresentar()
    {
        Console.WriteLine($"- {Nome} ({Funcao})");
    }
}

public class Maga
{
    public string Nome { get; set; }
    public Grimorio GrimorioEspecial { get; private set; }
    private List<Companheiro> companheiros;

    public Maga(string nome)
    {
        Nome = nome;
        GrimorioEspecial = new Grimorio();
        companheiros = new List<Companheiro>();
    }

    public void Recrutar(Companheiro c)
    {
        companheiros.Add(c);
    }

    public void MostrarGrupo()
    {
        Console.WriteLine($"--- Grupo de {Nome} ---");
        if (companheiros.Count == 0)
        {
            Console.WriteLine("Nenhum companheiro no grupo.");
        }
        else
        {
            foreach (var companheiro in companheiros)
            {
                companheiro.Apresentar();
            }
        }
        Console.WriteLine();
    }
}

class Program
{
    static void Main(string[] args)
    {
        Companheiro fern = new Companheiro("Fern", "Maga");
        Companheiro stark = new Companheiro("Stark", "Guerreiro");

        Maga frieren = new Maga("Frieren");

        frieren.Recrutar(fern);
        frieren.Recrutar(stark);

        frieren.GrimorioEspecial.FeiticoFavorito = "Feitiço para transformar uvas azuis em doces";

        frieren.MostrarGrupo();
        frieren.GrimorioEspecial.Abrir();
    }
}

/* 
 5. EXPLICAÇÃO SIMPLIFICADA:

 - COMPOSIÇÃO (Dependência Total):
   O Grimório nasce e morre com a Maga. Ele é criado diretamente dentro dela 
   (no construtor), logo não existe sozinho.

 - AGREGAÇÃO (Independência):
   Os Companheiros existem por si sós. Eles são criados fora e apenas 
   entram no grupo da Maga. Se a Maga sumir, os Companheiros continuam a existir.
*/