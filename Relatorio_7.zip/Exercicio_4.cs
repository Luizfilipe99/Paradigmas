using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class EntidadeCosmica
{
    public string Nome { get; set; }
    public string Origem { get; set; } = "Desconhecida";

    public EntidadeCosmica(string nome)
    {
        Nome = nome;
    }

    public virtual void Manifestar()
    {
        Console.WriteLine($"A entidade {Nome} se manifesta.");
        
        if (Origem != "Desconhecida")
        {
            Console.WriteLine($"Origem conhecida: {Origem}");
        }
    }
}

public class Profundo : EntidadeCosmica
{
    public Profundo(string nome) : base(nome)
    {
    }

    public override void Manifestar()
    {
        base.Manifestar();
        Console.WriteLine($"{Nome} emerge das profundezas do oceano soltando um gurgilo horripilante!");
    }
}

public class MiGo : EntidadeCosmica
{
    public MiGo(string nome) : base(nome)
    {
    }

    public override void Manifestar()
    {
        Console.WriteLine($"{Nome} (Mi-Go) zume suas asas fúngicas e se comunica telepaticamente.");
    }
}

public class Pesquisador
{
    public string Nome { get; set; }
    private List<EntidadeCosmica> entidadesCatalogadas;

    public Pesquisador(string nome)
    {
        Nome = nome;
        entidadesCatalogadas = new List<EntidadeCosmica>();
    }

    public void Catalogar(EntidadeCosmica e)
    {
        entidadesCatalogadas.Add(e);
        Console.WriteLine($"[Catálogo de {Nome}] Entidade '{e.Nome}' registrada com sucesso.");
    }

    public void LerCatalogo()
    {
        Console.WriteLine($"\n--- LENDO CATÁLOGO DO PESQUISADOR {Nome.ToUpper()} ---");
        foreach (var entidade in entidadesCatalogadas)
        {
            entidade.Manifestar();
            Console.WriteLine(new string('-', 45));
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        EntidadeCosmica entidadeGenerica = new EntidadeCosmica("Azathoth");
        Profundo profundo = new Profundo("Dagon");
        MiGo miGo = new MiGo("Fungo de Yuggoth");

        profundo.Origem = "Fossa das Marianas / R'lyeh";
        miGo.Origem = "Planeta Yuggoth";

        Pesquisador pesquisador = new Pesquisador("Dr. Armitage");

        Console.WriteLine("--- CATALOGANDO ENTIDADES ---");
        pesquisador.Catalogar(entidadeGenerica);
        pesquisador.Catalogar(profundo);
        pesquisador.Catalogar(miGo);

        pesquisador.LerCatalogo();
    }
}