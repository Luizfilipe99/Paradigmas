data Cafe = Cafe String Double Int
    deriving (Show)

descrever :: Cafe -> String
descrever (Cafe nome preco _) =
    "Café: " ++ nome ++ " | Preço: " ++ show preco

forca :: Cafe -> String
forca (Cafe _ _ intensidade)
    | intensidade >= 8 = "Forte"
    | intensidade >= 5 && intensidade <= 7 = "Equilibrado"
    | otherwise = "Suave"

precoDoPedido :: Bool -> Cafe -> Double
precoDoPedido comLeite (Cafe _ preco _) =
    if comLeite
        then preco + 2.0
        else preco

main :: IO ()
main = do
    let cafe1 = Cafe "Blue Mountain" 15.0 9   -- Forte
    let cafe2 = Cafe "Kopi Luwak" 25.0 6      -- Equilibrado
    let cafe3 = Cafe "Blend Leblanc" 10.0 3   -- Suave

    putStrLn "--- Menu do Leblanc ---"
    
    putStrLn (descrever cafe1 ++ " [" ++ forca cafe1 ++ "]")
    putStrLn (descrever cafe2 ++ " [" ++ forca cafe2 ++ "]")
    putStrLn (descrever cafe3 ++ " [" ++ forca cafe3 ++ "]")
    
    putStrLn "\n--- Simulação de Pedido ---"
    
    putStrLn "Preço do Kopi Luwak SEM leite:"
    print (precoDoPedido False cafe2)
    
    putStrLn "Preço do Kopi Luwak COM leite (+2.0):"
    print (precoDoPedido True cafe2)