data Etapa = NaFila | NoBanho | Concluido 
    deriving (Show, Eq)

data Atendimento = Atendimento {
    cliente :: String,
    servico :: String,
    valor :: Double,
    etapa :: Etapa
} deriving (Show)

descrever :: Atendimento -> String
descrever a = 
    "Cliente: " ++ cliente a ++ 
    " | Serviço: " ++ servico a ++ 
    " | Etapa: " ++ show (etapa a)

concluir :: Atendimento -> Atendimento
concluir a = a { etapa = Concluido }

arrecadado :: [Atendimento] -> Double
arrecadado atendimentos = sum (map valor atendimentosConcluidos)
  where
    atendimentosConcluidos = filter (\a -> etapa a == Concluido) atendimentos

main :: IO ()
main = do
    let at1 = Atendimento { cliente = "Deus do Rio", servico = "Banho Herbal", valor = 500.0, etapa = NaFila }
    let at2 = Atendimento { cliente = "Sem Rosto", servico = "Banquete e Banho", valor = 1000.0, etapa = NoBanho }
    let at3 = Atendimento { cliente = "Espírito do Rabanete", servico = "Banho Simples", valor = 100.0, etapa = NaFila }
    
    let listaOriginal = [at1, at2, at3]

    let listaAtualizada = [concluir at1, at2, concluir at3]

    putStrLn "--- ESTADO ORIGINAL DOS ATENDIMENTOS ---"
    mapM_ (putStrLn . descrever) listaOriginal
    putStrLn $ "Valor arrecadado (Original): " ++ show (arrecadado listaOriginal) ++ " de ouro\n"

    putStrLn "--- ESTADO ATUALIZADO DOS ATENDIMENTOS ---"
    mapM_ (putStrLn . descrever) listaAtualizada
    putStrLn $ "Valor arrecadado (Atualizada): " ++ show (arrecadado listaAtualizada) ++ " de ouro"