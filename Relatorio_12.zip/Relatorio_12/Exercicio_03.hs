data Esboco = Esboco {
    titulo :: String,
    tecnica :: String,
    horas :: Int
} deriving (Show)

esbocoMaisRecente :: [Esboco] -> String
esbocoMaisRecente [] = "Aviso: O caderno de esboços está vazio." 
esbocoMaisRecente (e:_) = "Último esboço: " ++ titulo e ++ " (Técnica: " ++ tecnica e ++ ")" 

contarEsbocos :: [Esboco] -> Int
contarEsbocos [] = 0 
contarEsbocos (_:es) = 1 + contarEsbocos es 

horasDesenhando :: [Esboco] -> Int
horasDesenhando [] = 0
horasDesenhando (e:es) = horas e + horasDesenhando es 

main :: IO ()
main = do
    let e1 = Esboco { titulo = "Castelo em Ruínas", tecnica = "Nanquim", horas = 5 }
    let e2 = Esboco { titulo = "Criatura do Pântano", tecnica = "Carvão", horas = 3 }
    let e3 = Esboco { titulo = "Floresta Sombria", tecnica = "Grafite", horas = 4 }
    
    let cadernoOriginal = [e1, e2, e3]
    let cadernoVazio = []

    putStrLn "--- CADERNO ORIGINAL ---"
    putStrLn (esbocoMaisRecente cadernoOriginal)
    putStrLn ("Número de esboços: " ++ show (contarEsbocos cadernoOriginal))
    putStrLn ("Total de horas a desenhar: " ++ show (horasDesenhando cadernoOriginal))

    putStrLn "\n--- CADERNO VAZIO ---"
    putStrLn (esbocoMaisRecente cadernoVazio)

    let eNovo = Esboco { titulo = "Gárgula de Pedra", tecnica = "Esferográfica", horas = 2 }
    let cadernoNovo = eNovo : cadernoOriginal

    putStrLn "\n--- COMPARAÇÃO DE CADERNOS ---"
    putStrLn ">> CADERNO NOVO:"
    putStrLn (esbocoMaisRecente cadernoNovo)
    putStrLn ("Número de esboços: " ++ show (contarEsbocos cadernoNovo))

    putStrLn "\n>> CADERNO ORIGINAL (O anterior deve continuar igual)[cite: 21]:"
    putStrLn (esbocoMaisRecente cadernoOriginal)
    putStrLn ("Número de esboços: " ++ show (contarEsbocos cadernoOriginal))

    -- 7.
    -- putStrLn ("Título com head: " ++ titulo (head cadernoVazio))