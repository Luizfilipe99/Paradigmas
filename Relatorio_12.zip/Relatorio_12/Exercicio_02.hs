pesoMaximo :: Double
pesoMaximo = 10.0

-- 7. 
-- pesoMaximo = 15.0

data Encomenda = Encomenda {
    destinatario :: String,
    peso :: Double,
    frete :: Double
} deriving (Show)

descrever :: Encomenda -> String
descrever enc = 
    "Para: " ++ destinatario enc ++ 
    " | Peso: " ++ show (peso enc) ++ "kg" ++ 
    " | Frete: " ++ show (frete enc) ++ " moedas"

cabemNaVassoura :: [Encomenda] -> [Encomenda]
cabemNaVassoura encomendas = filter (\enc -> peso enc <= pesoMaximo) encomendas

totalDeFretes :: [Encomenda] -> Double
totalDeFretes encomendas = sum (map frete encomendas)

main :: IO ()
main = do
    let enc1 = Encomenda { destinatario = "Osono (Padaria)", peso = 2.5, frete = 15.0 }
    let enc2 = Encomenda { destinatario = "Senhora (Tarte)", peso = 4.0, frete = 25.0 }
    let enc3 = Encomenda { destinatario = "Ursula (Quadro Grande)", peso = 12.0, frete = 50.0 }
    let enc4 = Encomenda { destinatario = "Tombo (Peças Bicicleta)", peso = 15.5, frete = 30.0 }
    
    let listaEncomendas = [enc1, enc2, enc3, enc4]

    putStrLn "--- TODAS AS ENCOMENDAS DO DIA ---"
    mapM_ (putStrLn . descrever) listaEncomendas
    
    putStrLn "\n--- ENCOMENDAS QUE CABEM NA VASSOURA ---"
    let possiveisLevar = cabemNaVassoura listaEncomendas
    mapM_ (putStrLn . descrever) possiveisLevar
    
    putStrLn "\n--- TOTAL ARRECADADO (FRETE) ---"
    putStrLn ("Total: " ++ show (totalDeFretes possiveisLevar) ++ " moedas")