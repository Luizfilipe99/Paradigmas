class Coquetelafterlife
    attr_reader :nome

    def initialize(nome, preco)
        @nome = nome
        @_preco = preco
    end

    def preco
        @_preco
    end

    def preco=(valor)
        if valor >= 5 && valor <= 200
            @_preco = valor <= 200
        else
            puts "preco invalido!"
        end
    end

    def ficha
        "cocktail: #{@nome} | preco: #{@_preco}"
    end
end

class Drinkdelenda < Coquetelafterlife
    attr_reader :lenda 

    def initialize(nome, preco, lenda)
        super(nome, preco)
        @lenda = lenda
    end

    def ficha
        "#{super} | lenda: #{@lenda}"
    end
end

cardapio = [
    Coquetelafterlife.new("nicola classico", 15),
    Drinkdelenda.new("johnny silverhand", 50, "rockerboy terrorista"),
    Drinkdelenda.new("jackie welles", 40, "mercenario de heywood")
]

cardapio.each do |drink|
    puts drink.ficha
end

puts "\n--- teste de reajuste de preco ---"

cardapio[1].preco = 500

cardapio[1].preco = 800

puts cardapio[1].ficha

#cardapio[0].nome = "Novo Nome"
#undefined method `nome=' for an instance of Coquetelafterlife (NoMethodError)