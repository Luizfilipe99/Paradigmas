class Instrumentista
    attr_reader :nome, :Instrumento

    def initialize(nome, instrumento)
        @nome = nome
        @Instrumento = instrumento
    end

    def interpretar(peca)
        raise notimplementederror, "erro: o metodo interpretar deve ser implementado nas subclasses."
    end
end

class Solista < Instrumentista
    def interpretar(peca)
        puts "#{@nome}, no #{@instrumento}, toca '#{peca}', conduzindo a melodia principal."
    end
end

class Acompanhador < Instrumentista
    
    def interpretar(peca)
      puts "#{@nome}, no #{@instrumento}, toca '#{peca}', acompanhando o ritmo do solista."
    end
  end

class Regente
    def initialize(nome)
        @nome = nome
        @orquestra = []
    end

    def convocar(instrumentista)
        @orquestra << instrumentista
    end

    def reger(peca)
        puts "o(a) regente #{@nome} levanta a batuta para a peca: #{peca}"
        @orquestra.each do |instrumentista|
            instrumentista.interpretar(peca)
        end
    end

    def escalacao
        @orquestra.map do |instrumentista|
            "#{Instrumentista.class}: #{instrumentista.nome}"
        end
    end
end

kaori = Solista.new("Kaori Miyazono", "Violino")
kousei = Acompanhador.new("Kousei Arima", "Piano")
hiroko = Regente.new("Hiroko Seto")

hiroko.convocar(kaori)
hiroko.convocar(kousei)

puts "--- APRESENTAÇÃO ---"
hiroko.reger("Introdução e Rondo Capriccioso")

puts "\n--- ESCALAÇÃO ---"
textos_escalacao = hiroko.escalacao
textos_escalacao.each do |texto|
  puts texto
end

puts "\n--- TESTE DE ERRO (ABSTRAÇÃO) ---"
figurante = Instrumentista.new("Figurante", "Triângulo")

# figurante.interpretar("Brilha Brilha Estrelinha")
#gera um NotImplementedError

