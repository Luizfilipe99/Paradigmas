class PhoneWave
    def enviar_dmail(mensagem)
        puts "Mensagem: '#{mensagem}' - enviada para o passado com sucesso!"
    end
end

class MembroDoLab
    attr_reader :numero, :nome

    def initialize(numero, nome)
        @numero = numero
        @nome = nome
    end
end

class LaboratorioDeGadgets
    def initialize
        @phonewave = PhoneWave.new
        @membros = []
    end

    def admitir(membro)
        @membros << membro
        puts "Novo integrante admitido: Lab Mem #{membro.numero} - #{membro.nome}"
    end

    def experimento(mensagem)
        puts "\n--- Iniciando Experimento PhoneWave ---"
        puts "Membros presentes:"
        @membros.each do |membro|
            puts " - Lab Mem #{membro.numero}: #{membro.nome}"
        end

    @phonewave.enviar_dmail(mensagem)
    end
end

okabe = MembroDoLab.new("001", "Rintaro Okabe")
kurisu = MembroDoLab.new("004", "Kurisu Makise")

laboratorio = LaboratorioDeGadgets.new

laboratorio.admitir(okabe)
laboratorio.admitir(kurisu)

laboratorio.experimento("El Psy Kongroo.")

# Explicação em comentário
=begin
EXPLICAÇÃO SIMPLIFICADA[cite: 7]:

- COMPOSIÇÃO (Dependência Total): 
  O PhoneWave é criado dentro do laboratório. Se o laboratório acabar, o PhoneWave morre com ele.

- AGREGAÇÃO (Independência): 
  Os membros existem por conta própria. Eles só "visitam" o laboratório e continuam existindo mesmo se ele fechar.
=end