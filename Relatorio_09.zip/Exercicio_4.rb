module Depoente
    def depor
      raise NotImplementedError, "O método depor precisa ser implementado pela classe."
    end
  end
  
  module Detivel
    def ser_detido
      puts "#{@nome} foi levado(a) sob custódia pela Scotland Yard!"
    end
  end
  
  class Envolvido
    attr_reader :nome
  
    def initialize(nome)
      @nome = nome
    end
  end
  
  class TestemunhaOcular < Envolvido
    include Depoente
  
    def depor
      puts "Testemunha #{@nome}: 'Eu vi uma figura escura saindo apressadamente pela porta dos fundos logo após o estrondo!'"
    end
  end
  
  class SuspeitoDoCrime < Envolvido
    include Depoente
    include Detivel
  
    def depor
      puts "Suspeito(a) #{@nome}: 'É impossível, eu estava no pub jogando dardos com meus amigos a noite toda!'"
    end
  end
  
  class Investigacao
    def initialize(caso)
      @caso = caso
      @envolvidos = [] 
    end
  
    def registrar(envolvido)
      @envolvidos << envolvido
    end
  
    def ouvir_todos
      puts "=== DEPOIMENTOS: Caso #{@caso} ==="
      @envolvidos.each do |envolvido|
        envolvido.depor
      end
    end
  
    def acionar_scotland_yard
      puts "\n=== AÇÃO POLICIAL ==="
      detiveis = @envolvidos.select { |envolvido| envolvido.respond_to?(:ser_detido) }
      
      detiveis.each do |suspeito|
        suspeito.ser_detido
      end
    end
  end
  
  testemunha = TestemunhaOcular.new("Sra. Hudson")
  suspeito1 = SuspeitoDoCrime.new("Professor Moriarty")
  suspeito2 = SuspeitoDoCrime.new("Coronel Moran")
  
  caso_estudo_em_vermelho = Investigacao.new("Um Estudo em Vermelho")
  
  caso_estudo_em_vermelho.registrar(testemunha)
  caso_estudo_em_vermelho.registrar(suspeito1)
  caso_estudo_em_vermelho.registrar(suspeito2)
  
  caso_estudo_em_vermelho.ouvir_todos
  caso_estudo_em_vermelho.acionar_scotland_yard