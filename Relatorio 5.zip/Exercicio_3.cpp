#include <iostream>
using namespace std;

void verificar_peso(float capacidade, float carga){
    cout<<"Peso atual: "<<carga<<"KG"<<endl;
    cout<<"capacidade disponivel: "<<capacidade-carga<<"KG"<<endl;
    cout<<endl;
}

float adicionar_carga(float capacidade, float carga, float carga_adicional){
    if ((capacidade - carga) >= carga_adicional){
        cout<<"Drone comporta a carga adicional"<<endl;
        cout<<endl;
        return (carga + carga_adicional);
    }else{
        cout<<"Drone não comporta a carga adicional"<<endl;
        cout<<endl;
        return carga;
    }
}

float remover_carga(float carga, float carga_removida){
    if ((carga - carga_removida) >= 0){
        cout<<"Carga removida"<<endl;
        cout<<endl;
        return (carga - carga_removida);
    }else{
        cout<<"O drone tem menos "<<carga_removida<<"KG de carga atual"<<endl;
        cout<<endl;
        return carga;
    }
}

int main() 
{
bool funcionamento = true;
float capacidade = 0.0, carga = 0.0, carga_adicional = 0.0, carga_removida = 0.0;
int acao;

cout<<"Entre com a capacidade do drone(KG): ";
cin>>capacidade;

    while(funcionamento){
        cout<<"=== SISTEMA DE CARGA DO DRONE ==="<<endl;
        cout<<"Verificar Carga Atual: 1"<<endl;
        cout<<"Carregar Pacote: 2"<<endl;
        cout<<"Descarregar Pacote: 3"<<endl;
        cout<<"Encerrar Operação: 4"<<endl;

        do{
            cin>>acao;
        }while(acao <1 || acao > 4);
        cout<<endl;

        switch (acao){
            case 1:
                verificar_peso(capacidade, carga);
                break;
            case 2:
                cout<<"Entre com a carga adicional: ";
                cin>>carga_adicional;
                carga = adicionar_carga(capacidade, carga, carga_adicional);
                break;
            case 3:
                cout<<"Entre com a carga removida: ";
                cin>>carga_removida;
                carga = remover_carga(carga, carga_removida);
                break;
            case 4:
                funcionamento = false;
                break;
        }
        cout<<endl;
    }
}