#include <iostream>
using namespace std;

float calcular_confiabilidade_sistema(float probabilidade[], int tamanho){
    float d = 1.0;
    for(int i = 0; i< tamanho; i++){
        d = d * probabilidade[i];
    }
    return d;
}

int main() 
{
    int n;
    float d;

    cin>>n;

    float* probabilidade = new float[n];

    for(int i=0;i<n;i++){
        float p;
        cout<<"Digite a probabilidade do componente "<<i+1<<" (ex: 0.95):";
        cin>>p;
        probabilidade[i]=p;
    }

    d = calcular_confiabilidade_sistema(probabilidade, n);

    cout<<"Probabilidade do sitema: "<<d<<" ("<<d*100<<"%)"<<endl;

    delete[] probabilidade;
    return 0;
}