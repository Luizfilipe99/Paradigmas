#include <iostream>
#include <iomanip>
using namespace std;

void ativar(int matriz[5][5], int f, int c){
    if(matriz[f][c] == 0){
        cout<<"Celula ja ativida: "<<endl<<endl;
        matriz[f][c] = 1;
    }else{
        cout<<"Celula ja ativida: "<<endl<<endl;
    }
}

void mapa(int matriz[5][5]){
    cout<<"--- Mapa da Matriz Solar ---"<<endl;
    for(int i = 0; i<5; i++){
        for(int j = 0; j<5; j++){
            cout<<"["<<matriz[i][j]<<"] ";
        }
        cout<<endl;
    }
    cout<<endl;
}

void relatorio(int matriz[5][5]){
    int a = 0, b = 0;
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(matriz[i][j] == 1){
                a++;
            }else{
                b++;
            }
        }
    }
    cout<<"=== RELATORIO FINAL DE OPERACAO ==="<<endl;
    cout<<"Total de celulas ATIVAS: "<<a<<endl;
    cout<<"Total de celulas INATIVAS: "<<b<<endl;
    cout << fixed << setprecision(2);
    cout<<"Capacidade Operacional: "<<(a/25.)*100.<<"%"<<endl;
}


int main() 
{
    int matriz[5][5];
    bool funcionamento = true;
    int acao, f, c;

    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            matriz[i][j]=0;
        }
    }

    while(funcionamento){
        cout<<"=== TELEMETRIA DO PAINEL SOLAR ==="<<endl;
        cout<<"1. Ativar Celula"<<endl;
        cout<<"2. Ver Mapa da Matriz"<<endl;
        cout<<"3. Sair"<<endl;

        do{
            cout<<"Escolha uma opcao: ";
            cin>>acao;
        }while(acao < 1 || acao > 3);

        switch(acao){
            case 1:
                cout<<"Entre com a fileira (0 - 4): ";
                cin>>f;
                cout<<"Entre com a coluna (0 - 4): ";
                cin>>c;
                ativar(matriz, f, c);
                break;
            case 2:
                mapa(matriz);
                break;
            case 3:
                relatorio(matriz);
                funcionamento = false;
                break;
        }
    }
    
}