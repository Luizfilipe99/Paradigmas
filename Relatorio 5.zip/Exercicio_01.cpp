#include <iostream>
using namespace std;

int combina_equipes(int n){
    if (n == 0) {
        return 0;
    }else if (n == 1){
        return 1;
    }else if (n > 1){
        return (combina_equipes(n-1) + combina_equipes(n-2));
    }else{
        cout<<"Numero de equipes invalido";
        return -1;
    }
}

int main() 
{
    int n;
    cout<<"Entre com o Numero de equipes: ";
    cin>>n;

    cout<<"Total de cenarios de confrontos possiveis: "<<combina_equipes(n);
    return 0;
}