package main
import "fmt"

func main() {
	var venda1 int
	var venda2 int
	var venda3 int

	fmt.Scanln(&venda1)
	fmt.Scanln(&venda2)
	fmt.Scanln(&venda3)

	total := (venda1 + venda2 + venda3)

	if total < 100 {
		fmt.Println("Meta nao atingida")
	}else{
		switch {
		case total >= 250:
			fmt.Printf("Total de vendas: %d unidades\n", total)
			fmt.Println("Classificação: Categoria Top Seller")
		case total >= 180:
			fmt.Printf("Total de vendas: %d unidades\n", total)
			fmt.Println("Classificação: Categoria Senior")
		case total >= 100:
			fmt.Printf("Total de vendas: %d unidades\n", total)
			fmt.Println("Classificação: Categoria pleno")
		}
	}
}