package main
import "fmt"

func geraescalaplantao(n int){
	b:=1
	for i:=0 ; i < n; i++ {
		fmt.Printf("%d° plantao no dia %d\n", i, b)
		b +=4
	}
}

func main() {
	var n int

	fmt.Scanln(&n)

	geraescalaplantao(n)
}