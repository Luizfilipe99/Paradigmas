package main
import "fmt"

func validarcodigorastreio(c string)(bool, string){
	if len(c) == 10{
		return true, "Codigo de rastreio registrado no sistema"
	}else{
		return false, "Erro: O codigo de rastreio deve ter exatamente 10 caracteres"
	}
}

func main() {
	var codigo string

	for {
		fmt.Println("entre com o codigo de rastreio: ")
		fmt.Scanln(&codigo)

		tente, mensagem := validarcodigorastreio(codigo)

		fmt.Println(mensagem)

		if tente {
			break
		}
	}
}