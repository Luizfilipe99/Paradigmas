package main
import "fmt"

func validaringresso(setor string, codigo int)(bool){
	if setor == "VIP" && codigo == 2026 {
		return true
	}else{
		return false
	}
}

func main() {
	var setor string
	var codigo int

	for {
		fmt.Println("Digite o setor do ingresso: ")
		fmt.Scanln(&setor)
		fmt.Println("Digite o código do ingresso: ")
		fmt.Scanln(&codigo)

		validar := validaringresso(setor, codigo)

		if validar {
			fmt.Println("Acesso liberado a area VIP")
			break
		}else{
			fmt.Println("Ingresso ou setor invalido. Tente novamente")
		}
	}
}