import java.util.ArrayList;

abstract class Monstro {
    private String nome;

    public Monstro(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public abstract String receita();
}

class Slime extends Monstro {
    public Slime(String nome) {
        super(nome);
    }

    @Override
    public String receita() {
        return "Ferver até perder a acidez e servir como gelatina.";
    }
}

class Mandragora extends Monstro {
    public Mandragora(String nome) {
        super(nome);
    }

    @Override
    public String receita() {
        return "Cortar em fatias finas e refogar para tirar o amargor.";
    }
}

class Panela {
    private String material;

    public Panela(String material) {
        this.material = material;
    }

    public String getMaterial() {
        return material;
    }
}

class Cozinheiro {
    private String nome;
    private Panela panela;
    private ArrayList<Monstro> ingredientes;

    public Cozinheiro(String nome, String materialDaPanela) {
        this.nome = nome;
        this.panela = new Panela(materialDaPanela);
        this.ingredientes = new ArrayList<>();
    }

    public void adicionarIngrediente(Monstro monstro) {
        ingredientes.add(monstro);
    }

    public void servirBanquete() {
        System.out.println("Banquete servido por " + nome + " preparado numa panela de " + panela.getMaterial() + "!");
        System.out.println("Pratos:");
        for (Monstro ingrediente : ingredientes) {
            System.out.println("- " + ingrediente.getNome() + ": " + ingrediente.receita());
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Slime slime = new Slime("Slime Verde");
        Mandragora mandragora = new Mandragora("Mandrágora Gritante");

        Cozinheiro senshi = new Cozinheiro("Senshi", "Ferro Fundido");

        senshi.adicionarIngrediente(slime);
        senshi.adicionarIngrediente(mandragora);

        senshi.servirBanquete();
        
        /*
        6.
        - COMPOSIÇÃO (Dependência Total): 
          A Panela nasce e morre junto com o Cozinheiro, pois é criada diretamente dentro dele.

        - AGREGAÇÃO (Independência): 
          Os Monstros têm vida própria. São criados de forma independente fora do Cozinheiro e não somem se ele for destruído.
        */
    }
}