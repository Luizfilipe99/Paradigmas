import java.util.HashMap;

interface Sobrenatural {
    void manifestar();
}

class Alienigena implements Sobrenatural {
    private String nome;

    public Alienigena(String nome) {
        this.nome = nome;
    }

    @Override
    public void manifestar() {
        System.out.println(nome + " aparece abduzindo vacas e emitindo luzes estranhas!");
    }
}

class EspiritoYoukai implements Sobrenatural {
    private String nome;

    public EspiritoYoukai(String nome) {
        this.nome = nome;
    }

    @Override
    public void manifestar() {
        System.out.println(nome + " surge como uma assombração flutuante assustadora!");
    }
}

class MapaDeAvistamentos {
    private HashMap<String, Sobrenatural> avistamentos;

    public MapaDeAvistamentos() {
        avistamentos = new HashMap<>();
    }

    public void registrar(String local, Sobrenatural ser) {
        avistamentos.put(local, ser);
    }

    public void investigar(String local) {
        Sobrenatural ser = avistamentos.get(local);
        if (ser == null) {
            System.out.println("O local " + local + " está tranquilo.");
        } else {
            System.out.println("Investigando " + local + "...");
            ser.manifestar();
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Alienigena alien = new Alienigena("Serpo");
        EspiritoYoukai youkai = new EspiritoYoukai("Rokurokubi");
        MapaDeAvistamentos mapa = new MapaDeAvistamentos();

        mapa.registrar("Fazenda Abandonada", alien);
        mapa.registrar("Templo Antigo", youkai);

        mapa.investigar("Fazenda Abandonada");
        mapa.investigar("Templo Antigo");
        mapa.investigar("Parque da Cidade"); 
    }
}