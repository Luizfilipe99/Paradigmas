import java.util.ArrayList;

class ItemDoCardapio {
    private String nome;
    private double preco;

    public ItemDoCardapio(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public double precoFinal() {
        return preco;
    }
}

class ComboLeblanc extends ItemDoCardapio {
    
    public ComboLeblanc(String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public double precoFinal() {
        return getPreco() * 0.9; 
    }
}

class CafeLeblanc {
    private ArrayList<ItemDoCardapio> cardapio;

    public CafeLeblanc() {
        this.cardapio = new ArrayList<>();
    }

    public void adicionar(ItemDoCardapio item) {
        cardapio.add(item);
    }

    public void mostrarCardapio() {
        System.out.println("--- Cardápio do Leblanc ---");
        for (ItemDoCardapio item : cardapio) {
            System.out.println("Item: " + item.getNome() + " | Preço Final: ¥" + String.format("%.2f", item.precoFinal()));
        }
    }
}

public class Main {
    public static void main(String[] args) {
        ItemDoCardapio item1 = new ItemDoCardapio("Leblanc Curry", 800.0);
        ItemDoCardapio item2 = new ItemDoCardapio("Leblanc Coffee", 400.0);
        ComboLeblanc combo1 = new ComboLeblanc("Curry + Coffee Combo", 1200.0);

        CafeLeblanc cafe = new CafeLeblanc();

        cafe.adicionar(item1);
        cafe.adicionar(item2);
        cafe.adicionar(combo1);

        cafe.mostrarCardapio();
    }
}