abstract class Morador {
    private String nome;

    public Morador(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public abstract void apresentar();
}

class Mago extends Morador {
    private String feitico;

    public Mago(String nome, String feitico) {
        super(nome);
        this.feitico = feitico;
    }

    @Override
    public void apresentar() {
        System.out.println("Sou o mago " + getNome() + " e o meu feitiço principal é: " + feitico);
    }
}

class DemonioDoFogo extends Morador {
    public DemonioDoFogo(String nome) {
        super(nome);
    }

    @Override
    public void apresentar() {
        System.out.println("Sou " + getNome() + ", o demónio do fogo, e sou eu que faço o castelo andar!");
    }
}

public class Main {
    public static void main(String[] args) {
        Morador mago = new Mago("Howl", "Metamorfose");
        Morador demonio = new DemonioDoFogo("Calcifer");

        System.out.println("--- Apresentação dos Moradores ---");
        mago.apresentar();
        demonio.apresentar();

        // 5
        // Morador moradorGenerico = new Morador("Genérico");
    }
}